﻿using System.ComponentModel.DataAnnotations;


namespace Morgenmadsbuffeten.Models
{
    public class ReceptionViewModel
    {
        /*public string ()
        {
            return "Hello from reception";
        }*/

        public string ReceptionId { get; set; }

    }
}
