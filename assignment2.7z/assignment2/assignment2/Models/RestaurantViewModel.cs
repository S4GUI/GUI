﻿using System.ComponentModel.DataAnnotations;

namespace Morgenmadsbuffeten.Models
{
    public class RestaurantViewModel
    {
        /*public string Index()
        {
            return "Hello from restaurant";
        }*/

        public string RestaurantId { get; set; }

    }
}
